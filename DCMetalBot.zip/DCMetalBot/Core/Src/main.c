/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>
#include<string.h>
//#include<math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TRUE 	1
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim14;
TIM_HandleTypeDef htim15;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM15_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM14_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

////////////////////////////////////////////////////////////////////////////Fuzzy Controller starts here////////////////////////////////
//#define MSLOW   67
//#define MSMEDIUM    83
//#define MSHIGH  100

#define MSLOW   30
#define MSMEDIUM    60
#define MSHIGH  90

enum ActiveRule { _NEAR, _MEDIUM, _FAR }; //Underscores have been used here because the program crashes without them once the aria.h is included. Posibly reserved on the header file
enum Rules { NEARNEAR, NEARMEDIUM, NEARFAR, MEDIUMNEAR, MEDIUMMEDIUM, MEDIUMFAR, FARNEAR, FARMEDIUM, FARFAR };

enum OARules {
	NEARNEARNEAR, NEARNEARMEDIUM, NEARNEARFAR, NEARMEDIUMNEAR, NEARMEDIUMMEDIUM, NEARMEDIUMFAR, NEARFARNEAR, NEARFARMEDIUM, NEARFARFAR,
	MEDIUMNEARNEAR, MEDIUMNEARMEDIUM, MEDIUMNEARFAR, MEDIUMMEDIUMNEAR, MEDIUMMEDIUMMEDIUM, MEDIUMMEDIUMFAR, MEDIUMFARNEAR, MEDIUMFARMEDIUM, MEDIUMFARFAR,
	FARNEARNEAR, FARNEARMEDIUM, FARNEARFAR, FARMEDIUMNEAR, FARMEDIUMMEDIUM, FARMEDIUMFAR, FARFARNEAR, FARFARMEDIUM, FARFARFAR
};


	float s1xUpper = 0;	//Hold the upper memebership function calculated for sonar1
	float s1xLower = 0;	//Hold the lower memebership function calculated for sonar1
	float s2xUpper = 0;	//Hold the upper memebership function calculated for sonar2
	float s2xLower = 0;	//Hold the lower memebership function calculated for sonar2
	float s3xUpper = 0;	//Hold the upper memebership function calculated for sonar3
	float s3xLower = 0;	//Hold the lower memebership function calculated for sonar3
	float a_Value = 0;		//used to hold one of the values used in calculations
	float b_Value = 0;		//used to hold one of the values used in calculating the membership function
	int s1ActiveRules[2];	//Holds the active rules for sonar 1
	int s2ActiveRules[2];	//Holds the active rules for sonar 2
	int s3ActiveRules[2];	//Holds the active rules for sonar 3
	float minimums[8];		//This is the array that will hold the minimum values of the active rules (for the rules that will be fired)
	int firingRules[8];
	int i;



	float sensorLiguistic[5] = { 20.00,30.00,60.00,90.00,100.00 };
//    float RMSLig_lable[27] = { 30,30,30,60,60,60,60,60,60,30,30,90,30,60,90,60,90,90,30,30,30,30,60,30,30,60,90 };
//	float LMSLig_lable[27] = { 30,60,90,60,30,30,60,30,30,60,30,60,60,60,60,30,90,90,90,90,90,90,60,90,60,60,90 };
//    MSLOW   341
//MSMEDIUM    682
// MSHIGH  1023

	float RMSLig_lable[27] = { MSMEDIUM,MSHIGH,MSHIGH,MSMEDIUM,MSHIGH,MSHIGH,MSMEDIUM,MSHIGH,MSHIGH,MSLOW,MSLOW,MSHIGH,MSMEDIUM,MSMEDIUM,MSHIGH,MSMEDIUM,MSHIGH,MSHIGH,MSLOW,MSLOW,MSLOW,MSMEDIUM,MSLOW,MSMEDIUM,MSLOW,MSHIGH,MSHIGH };
	float LMSLig_lable[27] = { MSHIGH,MSMEDIUM,MSLOW,MSMEDIUM,MSMEDIUM,MSLOW,MSMEDIUM,MSMEDIUM,MSMEDIUM,MSHIGH,MSLOW,MSLOW,MSHIGH,MSMEDIUM,MSMEDIUM,MSHIGH,MSHIGH,MSHIGH,MSHIGH,MSLOW,MSLOW,MSHIGH,MSMEDIUM,MSMEDIUM,MSHIGH,MSHIGH,MSHIGH };


	//double RMSLig_lable[27] = { 120,120,120,120,120,120,80,40,40,120,120,120,80,80,120,80,40,40,80,80,120,40,80,80,40,40,40 }; //Liguistic lable for the right motor speed (used the motor speed calculation only)
	//double LMSLig_lable[27] = { 40,40,40,40,40,40,40,80,120,40,40,40,40,40,80,40,120,120,40,40,40,80,80,40,120,80,80 };			//Liguistic lable for the Left motor speed (used in the calculation of the left motor speed)
	float rmsValue = 0; //hold the right motor speed
	float lmsValue = 0; //hold the right motor speed
	float sumOfMin = 0; //used to hold the sum of minimum. the value used in calculating the motor speeds.

	/*This function receives three parameters and returns the minimum one of the three.
	The function is used to find the minimum value for the firing rules*/
	float getMinimum(float x, float y, float z)
	{
		//return the ,mimimum between the three value
		return x < y ? (x < z ? x : z) : (y < z ? y : z);
	}

    /*This function stuck the firing rules in the array.This is done by taking the active rules and send them
	to the sorting funcion  sortRules(int x, int y, int z) that takes three parameter and return the active rule which will
	be used to set the motor speeds*/
	void getFiringRules(void) 	//Organise the firing rules
	{
		firingRules[0] = sortRules(s1ActiveRules[0], s2ActiveRules[0], s3ActiveRules[0]);		//firingRules[0] takes the firing rules that is determined by taking s5ActiveRules[0], s6ActiveRules[0] and s7ActiveRules[0]
		firingRules[1] = sortRules(s1ActiveRules[0], s2ActiveRules[0], s3ActiveRules[1]);		//firingRules[1] takes the firing rules that is determined by taking s5ActiveRules[0], s6ActiveRules[0] and s7ActiveRules[1]
		firingRules[2] = sortRules(s1ActiveRules[0], s2ActiveRules[1], s3ActiveRules[0]);		//
		firingRules[3] = sortRules(s1ActiveRules[0], s2ActiveRules[1], s3ActiveRules[1]);		//
		firingRules[4] = sortRules(s1ActiveRules[1], s2ActiveRules[0], s3ActiveRules[0]);		//
		firingRules[5] = sortRules(s1ActiveRules[1], s2ActiveRules[0], s3ActiveRules[1]);		//
		firingRules[6] = sortRules(s1ActiveRules[1], s2ActiveRules[1], s3ActiveRules[0]);		//
		firingRules[7] = sortRules(s1ActiveRules[1], s2ActiveRules[1], s3ActiveRules[1]);		//firingRules[7] takes the firing rules that is determined by taking s5ActiveRules[1], s6ActiveRules[1] and s7ActiveRules[1]

		//ofstream myfile("SonarReading.txt", ios::out | ios::app);  //open the file in append mode
																   //Just print the firing rule to make sure they are correct
		/*for ( i = 0; i < 8; i++)
		{
			printf("The firingRule: %d is: %d\n",i,firingRules[i]);		//This prints on the screen for debuging
			//myfile << "The firingRule:= " << i << " is:= " << firingRules[i] << endl;	//write to the file for debuging
		}*/
		//myfile.close(); //close the file

	}

    /*This function calculates the motor speed. The function does thi acumulating the product of the minimum and the value
	of the active Motor speed liguistic values pointed to by the fireing rules. The minimum values are also summed up to be
	used in the final calulation*/
	void findMotorSpeeds(void)
	{
		sumOfMin = 0;	//Clear the sumOfMinium variable first
		rmsValue = 0;	//Clear the rightMotorSpeed variable
		lmsValue = 0;	//Clear the leftMotor speed

		for ( i = 0; i < 8; i++)  //there are eight active firing rule at a time (i.e. 0-7)
		{
			sumOfMin += minimums[i];
			rmsValue = rmsValue + (minimums[i] * RMSLig_lable[firingRules[i]]);
			lmsValue = lmsValue + (minimums[i] * LMSLig_lable[firingRules[i]]);
		}
		/*The condition below was put up to prevent the program from deviding with zero. This is dones as
		 to counteract the error that resulted in nan being printed on the screen instead of the actual value
		 It was later found that the error was created by the "getMinimum(double x, double y, double z)" function which is corrected
		 now but this will still be of use though*/
		if (sumOfMin > 0.000)
		{
			rmsValue = rmsValue / sumOfMin;	 //divide the acumulated value by the minimum value
			lmsValue = lmsValue / sumOfMin;  //devide the accumulated value by the minimum to get the final lms value
		}

		//printf("RMS is =: %f\n",rmsValue);
		//printf("LMS is =: %f\n",lmsValue);

		//printf("\n\n\n\n_______________________________________End of the flc_ObstacleAvoidance_Class__________________________________________\n\n\n\n\n");

	}



    /*This function finds the minimu value between the calculated membership function from the three sonar
	and load it in the arrray that will be used for the calculation of the motor speed. The function is called
	stackUpMinimum as it only stack up the minimum in the array of minimums*/
	void stackUpMinimums(void)  //ask for the minimum value, load the minimums in the minimum[] array and print them on the screen for diagonostic purpose
	{
		//printf("\n\nstacking up the minimum Values\n");
		minimums[0] = getMinimum(s1xUpper, s2xUpper, s3xUpper);    //Get the minimum between sonar1Upper, sonar2Upper and sonar3Upper membership function
		minimums[1] = getMinimum(s1xUpper, s2xUpper, s3xLower);	   //Get the minimum between sonar1Upper, sonar2Upper and sonar3Lower membership function
		minimums[2] = getMinimum(s1xUpper, s2xLower, s3xUpper);		//Get the minimum between sonar1Upper, sonar2Lower and sonar3Upper membership function
		minimums[3] = getMinimum(s1xUpper, s2xLower, s3xLower);		//Get the minimum between sonar1Upper, sonar2Lower and sonar3Lower membership function
		minimums[4] = getMinimum(s1xLower, s2xUpper, s3xUpper);		//Get the minimum between sonar1Lower, sonar2Upper and sonar3Upper membership function
		minimums[5] = getMinimum(s1xLower, s2xUpper, s3xLower);		//Get the minimum between sonar1Lower, sonar2Upper and sonar3Lower membership function
		minimums[6] = getMinimum(s1xLower, s2xLower, s3xUpper);		//Get the minimum between sonar1Lower, sonar2Lower and sonar3Upper membership function
		minimums[7] = getMinimum(s1xLower, s2xLower, s3xLower);		//Get the minimum between sonar1Lower, sonar2Lower and sonar3Lower membership function

		//The value loaded in the array are printed on the file for trouble shooting. This was made to monitor the activity of the
		//getMinimum which was giving me tough time as it could work well in Dev C/C++ and created nan in visual studio
		//ofstream myfile("SonarReading.txt", ios::out | ios::app);
	/*	for (i = 0; i < 8; i++)
		{
			printf("The minim: %d is =: %f\n",i, minimums[i]);		//This prints on the screen
			//myfile << "The minim: " << i << " is:= " << minimums[i] << endl;	//This prints to the file
		}*/
		//myfile.close();	//just close the file
	}


	void GetDegreeOfMembershipValue(float sonarOneReading, float sonarTwoReading, float sonarThreeReading )
	{
	   // printf("\n-------SonarOne-------------\n");
	    /*
	    The first conditional statement checks if the robot is too close to the obstacle.
	    If so, the upper membership function will be set to one and the lower membership function will be set to 0
	    as it is in the liguistic labels. No calculation will be required if the first condition is satisfied.
	    */
	    if (sonarOneReading <= sensorLiguistic[1]) //if the sensor reading closer to the obstacle
        {
            s1xUpper = 1;
			s1xLower = 0;

			s1ActiveRules[0] = _NEAR;		//the firing rule for this sensor are set to NEAR AND NEAR as they are
			s1ActiveRules[1] = _NEAR;		//touching the near section only (trapezoid)
			//printf("\nThe value of s1xUpper =: %f\n",s1xUpper); //These are printed out on the screen as the robot runs. They makes it posible to check the reading from the
			//printf("The s1xLower Value is: %f\n",s1xLower);     //sensors while the robot is in the idle  state. Help in trouble shooting
			//printf("SonarOne active Rules are _NEAR AND _NEAR FULLY");  //This help in trouble shooting only to check which rules were selected for this sensor
        }
        if (sonarOneReading > sensorLiguistic[1] && sonarOneReading <= sensorLiguistic[2])
		{
			a_Value = sensorLiguistic[1];		//load the a_value reading with the value from the liguistic lables to be used in calculation
			b_Value = sensorLiguistic[2];		//load the b_value reading with the value from the liguistic lables to be used in calculation
			s1xUpper = ((sonarOneReading - a_Value) / (b_Value - a_Value));	//Calculate the Upper membership function
			s1xLower = ((b_Value - sonarOneReading) / (b_Value - a_Value));	//Calculate the lower membership function of sornar 5
			//printf("\n\nThe value of s1xUpper =:%f\n", s1xUpper);       //Used only to help with debug as this will show the value for the Upper_membership function
			//printf("The s1xLower Value is =: %f\n",s1xLower) ;       //Used only to help with debug as this will show the value for the Lower_membership function

			//The two conditional statement check to see if the sonar reading is less than or greater than the point where the
			//two liguistic lable meet. This help keep the the sitting of the active firing rules simple, so they
			//switch over so that the function that will sort the firing rules will not have difficulties.
			if (sonarOneReading > sensorLiguistic[1] && sonarOneReading <= ((sensorLiguistic[1] + sensorLiguistic[2])) / 2)
			{
				s1ActiveRules[0] = _NEAR;	//set the upper active rule for sonar 5 to NEAR
				s1ActiveRules[1] = _MEDIUM;	//Set the lower active rule for sonar 5 to MEDIUM
				//printf("Sonar1 active Rules are _NEAR AND MEDIUM\n");    //Printed on the screen just for trouble shooting
			}
			if (sonarOneReading < sensorLiguistic[2] && sonarOneReading >= ((sensorLiguistic[1] + sensorLiguistic[2])) / 2)
			{
				s1ActiveRules[0] = _MEDIUM;		//assign the upper active rule for sonar5 to s5ActiveRules[0] as _MEDIUM
				s1ActiveRules[1] = _NEAR;		//assign the upper active rule for sonar5 to s5ActiveRules[0] as _NEAR
				//printf("Sonar1 active Rules are MEDIUM AND _NEAR\n");   //Print this on the screen for diagnostics purposes
			}
		}

			/*This conditional statement checks if the sensor reading is in the centre of the MEDIUM liguistic label
			and then set the upper member ship function to 1 and the lower membership function to 0 as it is in the
            liguistic lable if the condition is true. The active rules are set all to medium as it only medium that
            is touched by the reading.
            If the condition is met, the is nor need to calculate as this is in the center.*/
        if (sonarOneReading == sensorLiguistic[2]) //the medium is full active and both NEAR AND FAR are zero
		{
			s1xUpper = 1;		//assign a 1 to the upper membership function as no need for calculation because this is 100% Medium and
			s1xLower = 0;		//assign a 0 to the lower membership function
			//printf("\n\nThe value of s1xUpper =: %f\n",s1xUpper);   //print this on the screen for diagnostics. it will show the value assigned to upper membership function for sonar5r sonar5
			//printf("The s1xLower Value is: %f",s1xLower);   //Print this out just for diagnostics purpose
			s1ActiveRules[0] = _MEDIUM;		//hold the upper active rule
			s1ActiveRules[1] = _MEDIUM;		//Hols the lower active rule for sonar5
			//printf("Sonar1 active Rules are MEDIUM AND _MEDIUM FULLY"); //Print this out just for debuging purpose
		}


		if (sonarOneReading > sensorLiguistic[2] && sonarOneReading < sensorLiguistic[3])
		{
			a_Value = sensorLiguistic[2];		//load the a_value reading with the value from the liguistic lables to be used in calculation
			b_Value = sensorLiguistic[3];		//load the b_value reading with the value from the liguistic lables to be used in calculation
			s1xUpper = ((sonarOneReading - a_Value) / (b_Value - a_Value));		//Calculate the upper membership function
			s1xLower = ((b_Value - sonarOneReading) / (b_Value - a_Value));		//calculate the lower membershhip function
			//printf("\n\nThe value of s1xUpper =: %f\n",s1xUpper);    //print this value on the screen for diagnostics.
			//printf("The s1xLower Value is: %f\n",s1xLower);          //print the lower value on the screen for diagnostics

			/*The conditional statement will be activated if the sonar reading value is greater than the 2nd value of the sensorLiguistic
			and less than or equals to the mean of the 2nd and 3rd sensorLiguistic value. This will idicate the interset point of the
			two liguistic label*/
			if (sonarOneReading > sensorLiguistic[2] && sonarOneReading <= ((sensorLiguistic[2] + sensorLiguistic[3])) / 2)
			{
				s1ActiveRules[0] = _MEDIUM;		//assign the upper active rule for sonar5 to s5ActiveRules[0] as _MEDIUM
				s1ActiveRules[1] = _FAR;		//assign the lower active rule for sonar5 to s5ActiveRules[1] as _FAR
				//printf("Sonar1 active Rules are _MEDIUM AND FAR\n");
			}
			if (sonarOneReading > (((sensorLiguistic[2] + sensorLiguistic[3])) / 2) && sonarOneReading < sensorLiguistic[3])
			{
				s1ActiveRules[0] = _FAR;		//Otherwise assign the upper active rule for sonar5 to s5ActiveRules[0] as _FAR and
				s1ActiveRules[1] = _MEDIUM;		//assign the lower active rule for sonar5 to s5ActiveRules[1] as _MEDIUM
				//printf("Sonar1 active Rules are FAR AND _MEDIUM\n");
			}
		}

		/*If the sonar5 reading FAR only (that the reading is above the last point of the medium), then the upper membership function is set to 1
		and the lower membership function set to 0.This is done this way because the upper membership (degree of membership) is 100% FAR and the lower membership function is 0% FAR in the FAR region.
		With this condition all the active rules for this sensors will be set to FAR*/
		if (sonarOneReading >= sensorLiguistic[3]) //the medium is full active and both NEAR AND FAR are zero
		{
			s1xUpper = 1;
			s1xLower = 0;
			//printf("\n\nThe value of s1xUpper =: %f\n",s1xUpper);  //print this on the screen for diagnostics. it will show the value assigned to upper membership function for sonar5
			//printf("The s1xLower Value is: %f\n", s1xLower);			//print this on the screen for diagnostics. it will show the value assined to the lower membership funtion
			s1ActiveRules[0] = _FAR;		//assign the upper active rule for sonar5 to s5ActiveRules[0] as _FAR
			s1ActiveRules[1] = _FAR;		//assign the lower active rule for sonar5 to s5ActiveRules[1] as _FAR

			//printf("Sonar5 active Rules are FAR AND _FAR FULLY\n");
		}


		//printf("\n----------SonarTwo-----------\n");

		//for sonar6reading
		/*The first conditional statement check if the robot is close to the edge
		if so the upper membership function will be set to one and the lower membership function
		for the sensor will be set to zero as it is in the liguistic labels.
		No calcultion will be required if this first condition is satisfied
		It should be noted that the sensorLiguistic[0] has not been used in this program
		as it is not in the useful part of the LiuisticLabel in the actual diagrams*/
		if (sonarTwoReading <= sensorLiguistic[1]) //if the sensor reading is less then 400.00
		{
			s2xUpper = 1;
			s2xLower = 0;
			s2ActiveRules[0] = _NEAR;
			s2ActiveRules[1] = _NEAR;
			//printf("\n\nThe value of s2xUpper =: %f\n",s2xUpper);
			//printf("The s2xLower Value is: %f\n",s2xLower );
			//printf("Sonar2 active Rules are _NEAR AND _NEAR FULLY\n");
		}

		/*The conditional statement below check is the value obtained is between the first value in the linguistic label
		and the second value in the linguistic label. The second value is the value in the middle of the Medium labeled triangle.
		and the firstt value is the value on the right of that value.
		The program was made to check these to ensure the equation used in the calculation of the membership function are correct
		this if the condition is met, the program will the calculation as shown in the body of the conditional statement*/
		if (sonarTwoReading > sensorLiguistic[1] && sonarTwoReading <= sensorLiguistic[2])
		{
			a_Value = sensorLiguistic[1];		//Assign the sensorLiguistic[1] to the aValue and
			b_Value = sensorLiguistic[2];		//assign the sensorLiguistic[2] to the bvalue.
												//(the sensorLiguistic[] could be used directly but it was done this way to make it more readable as this show similarity to the hand worked calculation.
			s2xUpper = ((sonarTwoReading - a_Value) / (b_Value - a_Value));	//Do the calculation for the upperMembership function
			s2xLower = ((b_Value - sonarTwoReading) / (b_Value - a_Value));	//Calculate the Lower Membership function
			//printf("\n\nThe value of s2xUpper =: %f\n",s2xUpper);	//and then print the calculation results on the screen to help trouble shooting
			//printf("The s2xLower Value is: %f\n",s2xLower);			//

			/*The active rules for this sensor have to be set depending on weather the sensor reading is below the middle point between the two values
			or above it. THis was made this way to ensure to simply the selection of the firing rules at the end.
			If its less lower than the center of the to value, then s6ActiveRules[0] is set to NEAR and it s6ActiveRules[1] set to MEDIUM.
			It should be noted that the s6ActiveRules[] array holds the active rules for sonar6. if it is high than the center point between the two values,
			the above will be reversed as it can be seen in the second conditional statement*/
			if (sonarTwoReading > sensorLiguistic[1] && sonarTwoReading <= ((sensorLiguistic[1] + sensorLiguistic[2])) / 2)
			{
				s2ActiveRules[0] = _NEAR;		//assign the upper active rule for sonar6 to s6ActiveRules[0]
				s2ActiveRules[1] = _MEDIUM;		//assign the upper active rule for sonar6 to s6ActiveRules[1]
				//printf("Sonar2 active Rules are _NEAR AND MEDIUM\n"); //print this on the screen to help trouble shooting
			}
			if (sonarTwoReading < sensorLiguistic[2] && sonarTwoReading >= ((sensorLiguistic[1] + sensorLiguistic[2])) / 2)
			{
				s2ActiveRules[0] = _MEDIUM;		//assign the upper active rule for sonar6 to s6ActiveRules[0]
				s2ActiveRules[1] = _NEAR;		//assign the upper active rule for sonar6 to s6ActiveRules[2]
				//printf("Sonar2 active Rules are MEDIUM AND _NEAR\n");
			}
		}

		/*The if statement below, checks if the sensor reading is equals to the value in the center of the MEDIUM triangle. If this is true
		then no need for calculation, the UpperMembership function is simply set to 1 and the lower is set to 0. because is this is, the
		upper membership function will be fully active and the lower is disabled*/
		if (sonarTwoReading == sensorLiguistic[2]) //the medium is full active and both NEAR AND FAR are zero
		{
			s2xUpper = 1;		//assign a 1 to the upper membership function as no need for calculation because this is 100% Medium
			s2xLower = 0;		//assign a 0 to the Lower membership function as no need for calculation because this is 0% Medium
			//printf("\n\nThe value of s2xUpper =: %f\n",s2xUpper);	//print this on the screen to help trouble shooting
			//printf("The s2xLower Value is: %f\n",s2xLower);			//print this on the screen to help trouble shooting
			s2ActiveRules[0] = _MEDIUM;						//Both Upper and Lower active rules are MEDIUM in this state
			s2ActiveRules[1] = _MEDIUM;
			//printf("Sonar2 active Rules are MEDIUM AND _MEDIUM FULLY\n");	//print this on the screen to help trouble shooting
		}

		/* The conditional statement below will check is the reading of the sensor is above the sensorLiguistic[2] and lower than sensorLiguistic[3].
		if this condition is satisfied, the calculation will be carried out as shown in the body of the conditional statement. If is is not then the program
		will skip this and move on to the next conditional statement.*/
		if (sonarTwoReading > sensorLiguistic[2] && sonarTwoReading < sensorLiguistic[3])
		{
			a_Value = sensorLiguistic[2];			//Assign the sensorLiguistic[2] to the aValue and
			b_Value = sensorLiguistic[3];			//assign the sensorLiguistic[3] to the bvalue.
			s2xUpper = ((sonarTwoReading - a_Value) / (b_Value - a_Value));		//calculating the upper membership function
			s2xLower = ((b_Value - sonarTwoReading) / (b_Value - a_Value));		//calculate the lower membership function
			//printf("\n\nThe value of s2xUpper =: %f\n",s2xUpper);		//Print the Upper membership function on the screen just for trouble shooting
			//printf("The s2xLower Value is: %f\n",s2xLower);				//Print the lower membership function in the screen just for trouble shooting

			/*To determines what hold what in terms of the active rules for this sensor, the program check if the reading is above the sensorLiguistic[2]
			and below or equal to the value in the middle between sensorLiguistic[2] and sensorLiguistic[3] which just the mean between the two and
			if so, s6ActiveRules[0] is assigned MEDIUM and s6ActiveRules[1] is assigned the active rule FAR. the order of assignment is very important in
			program as it will be used in the final part to determine the firing rules*/
			if (sonarTwoReading > sensorLiguistic[2] && sonarTwoReading <= ((sensorLiguistic[2] + sensorLiguistic[3])) / 2)
			{
				s2ActiveRules[0] = _MEDIUM;  //hold the upper active value
				s2ActiveRules[1] = _FAR;
				//printf("Sonar2 active Rules are _MEDIUM AND FAR\n");
			}
			/*If the sonar6 reading is above the mean of the two values, then s6ActiveRules[0] is assigned FAR and is assigned MEDIUM as below */
			if (sonarTwoReading > (((sensorLiguistic[2] + sensorLiguistic[3])) / 2) && sonarTwoReading < sensorLiguistic[3])
			{
				s2ActiveRules[0] = _FAR;  //hold the upper active value
				s2ActiveRules[1] = _MEDIUM;
				//printf("Sonar2 active Rules are FAR AND _MEDIUM\n");
			}
		}
		/*If the sonar6 reading FAR only (that the reading is above the last point of the medium), then the upper membership function is simply set to 1
		and the lower membership function set to 0.This is done this way because the upper membership (degree of membership) is 100% FAR and the lower membership function is 0% FAR in the FAR region.
		With this condition all the active rules for this sensors will be set to FAR*/
		if (sonarTwoReading >= sensorLiguistic[3]) //the medium is full active and both NEAR AND FAR are zero
		{
			s2xUpper = 1;
			s2xLower = 0;
			//printf("\n\nThe value of s2xUpper =: %f\n", s2xUpper);
			//printf("The s2xLower Value is: %f\n",s2xLower);
			s2ActiveRules[0] = _FAR;		//assign the upper active rule for sonar6 to s6ActiveRules[0] as _FAR
			s2ActiveRules[1] = _FAR;		//assign the upper active rule for sonar6 to s6ActiveRules[1] as _FAR
			//printf("Sonar2 active Rules are FAR AND _FAR FULLY\n");
		}



		//printf("\n----------SonarThree-----------\n");
		//////////////////////////////////////for sonar7 now////////////////////////////////////////////////////////
		/*The first conditional statement check if the robot's Sonar7 is close to the edge
		if so the upper membership function will be set to one and the lower membership function
		for the sensor will be set to zero as it is in the liguistic labels.
		No calcultion will be required if this first condition is satisfied
		It should be noted that the sensorLiguistic[0] has not been used in this program
		as it is not in the useful part of the LiuisticLabel in the actual diagrams*/
		if (sonarThreeReading <= sensorLiguistic[1]) //if the sensor reading is less then 400.00 in the membership function diagram
		{
			s3xUpper = 1;					//assign a 1 to the upper membership function as no need for calculation because this is 100% NEAR
			s3xLower = 0;					//assign a 0 to the Lower membership function as no need for calculation because this is 0% NEAR in the NEAR region
			s3ActiveRules[0] = _NEAR;		//assign the upper active rule for sonar7 to s7ActiveRules[0] as _NEAR
			s3ActiveRules[1] = _NEAR;		//assign the upper active rule for sonar7 to s7ActiveRules[1] as _NEAR
			//printf("\n\nThe value of s3xUpper =: %f\n",s3xUpper);	//Print this on the screen to help to see what is happening
			//printf("The s3xLower Value is: %f\n", s3xLower);			//Print this on the screen to help show what is happening to the programmer
			//printf("Sonar3 active Rules: _NEAR AND NEAR FULLY\n");	//print this on the screen to show what Membership functions has been assinged
		}
		if (sonarThreeReading > sensorLiguistic[1] && sonarThreeReading <= sensorLiguistic[2])
		{
			a_Value = sensorLiguistic[1];		//Assign the sensorLiguistic[1] to the aValue and
			b_Value = sensorLiguistic[2];		//Assign the sensorLiguistic[2] to the bValue
			s3xUpper = ((sonarThreeReading - a_Value) / (b_Value - a_Value));	//Print this on the screen to help to see what calculation result is for this value
			s3xLower = ((b_Value - sonarThreeReading) / (b_Value - a_Value));	//Print this on the screen to help show what is happening to the programmer
			//printf("\n\nThe value of s3xUpper =: %f\n",s3xUpper);
			//printf("The s3xLower Value is: %f\n",s3xLower);

			if (sonarThreeReading > sensorLiguistic[1] && sonarThreeReading <= ((sensorLiguistic[1] + sensorLiguistic[2])) / 2)
			{
				s3ActiveRules[0] = _NEAR;			//assign the upper active rule for sonar7 to s7ActiveRules[0] as _NEAR
				s3ActiveRules[1] = _MEDIUM;			//assign the upper active rule for sonar7 to s7ActiveRules[1] as _MEDIUM
				//printf("Sonar3 active Rules are _NEAR AND MEDIUM\n");	//print this on the screen to show what Membership functions has been assinged
			}
			if (sonarThreeReading < sensorLiguistic[2] && sonarThreeReading >= ((sensorLiguistic[1] + sensorLiguistic[2])) / 2)
			{
				s3ActiveRules[0] = _MEDIUM;			//assign the upper active rule for sonar7 to s7ActiveRules[0] as _MEDIUM
				s3ActiveRules[1] = _NEAR;			//assign the upper active rule for sonar7 to s7ActiveRules[1] as _NEAR
				//printf("Sonar3 active Rules are MEDIUM AND _NEAR\n");  //Print this on the screen to help in trouble shooting (just an indicator to the programmer)
			}
		}
		/*The if statement below, checks if the sensor reading is equals to the value in the center of the MEDIUM triangle. If this is true
		then no need for calculation, the UpperMembership function is simply set to 1 and the lower is set to 0. because is this is, the
		upper membership function will be fully active and the lower is disabled*/
		if (sonarThreeReading == sensorLiguistic[2]) //the medium is full active and both NEAR AND FAR are zero
		{
			s3xUpper = 1;		//assign a 1 to the upper membership function as no need to do the calculations
			s3xLower = 0;		//and assign the lower membership function to 0
			//printf("\n\nThe value of s3xUpper =: %f\n",s3xUpper);	//print this on the screen for diagnostics. it will show the value
			//printf("The s3xLower Value is: %f\n",s3xLower);			//print this on the screen for diagnostics. it will show the value aasigned to lower membership function
			s3ActiveRules[0] = _MEDIUM;		//assign the upper active rule for sonar7 to s7ActiveRules[0] as _MEDIUM
			s3ActiveRules[1] = _MEDIUM;		//assign the upper active rule for sonar7 to s7ActiveRules[1] as _MEDIUM
			//printf("Sonar3 active Rules are MEDIUM AND _MEDIUM FULLY\n");
		}
		if (sonarThreeReading > sensorLiguistic[2] && sonarThreeReading < sensorLiguistic[3])
		{
			a_Value = sensorLiguistic[2];
			b_Value = sensorLiguistic[3];
			s3xUpper = ((sonarThreeReading - a_Value) / (b_Value - a_Value));	//Calculate the Upper membership function
			s3xLower = ((b_Value - sonarThreeReading) / (b_Value - a_Value));	//calculate the lower membership funtion
			//printf("\n\nThe value of s3xUpper =: %f\n",s3xUpper);	//print this on the screen for diagnostics. it will show the calculated value
			//printf("The s3xLower Value is: %f\n",s3xLower);			//print this on the screen for diagnostics. it will show the calculated value

			if (sonarThreeReading > sensorLiguistic[2] && sonarThreeReading <= ((sensorLiguistic[2] + sensorLiguistic[3])) / 2)
			{
				s3ActiveRules[0] = _MEDIUM;			//assign the upper active rule for sonar7 to s7ActiveRules[0] as _MEDIUM
				s3ActiveRules[1] = _FAR;			//assign the lower active rule for sonar7 to s7ActiveRules[1] as _FAR
				//printf("Sonar3 active Rules are _MEDIUM AND FAR\n");
			}
			if (sonarThreeReading > (((sensorLiguistic[2] + sensorLiguistic[3])) / 2) && sonarThreeReading < sensorLiguistic[3])
			{
				s3ActiveRules[0] = _FAR;			//assign the upper active rule for sonar7 to s7ActiveRules[0] as _FAR
				s3ActiveRules[1] = _MEDIUM;			//assign the lower active rule for sonar7 to s7ActiveRules[1] as _MEDIUM
				//printf("Sonar3 active Rules are FAR AND _MEDIUM\n");
			}
		}
		if (sonarThreeReading >= sensorLiguistic[3]) //the medium is full active and both NEAR AND FAR are zero
		{
			s3xUpper = 1;
			s3xLower = 0;
			//printf("\n\nThe value of s3xUpper =: %f\n",s3xUpper);	//print this on the screen for diagnostics. it will show the calculated value
			//printf("The s3xLower Value is: %f\n",s3xLower);			//on the screen for diagnostics to show the calculated value
			s3ActiveRules[0] = _FAR;	//assign the upper active rule for sonar7 to s7ActiveRules[0] as _FAR
			s3ActiveRules[1] = _FAR;	//assign the upper active rule for sonar7 to s7ActiveRules[1] as _FAR
			//printf("Sonar3 active Rules are FAR AND _FAR FULLY\n");
		}


		stackUpMinimums(); //ask for the minimum value to be predent on screen
		getFiringRules();	//Organise the firing rules
		findMotorSpeeds();  //Calculate the motor speed and print them on the screen
	}














	/*sortRules(int x, int y, int z) function takes three parameters which are all representing the active rule for each sonar sensor used
	(i.e. sonar5,sonar6 and sonar7). The function works more like the "look up tables" used in Assembers for most MCU programming*/
	int sortRules(int x, int y, int z)
	{
		if (x == _NEAR && y == _NEAR && z == _NEAR)			//1.	If sonar5 is NEAR, sonar6 is NEAR and sonar7 is NEAR
		{
			//printf("NEARNEARNEAR\n");					//Print this on the screen for debuging purpose only
			return NEARNEARNEAR;							//return the firing rule
		}
		if (x == _NEAR && y == _NEAR && z == _MEDIUM)		//2.	If sonar5 is NEAR, sonar6 is NEAR and sonar7 is MEDIUM
		{
			//printf("NEARNEARMEDIUM\n");				//Print this on the screen for debuging purpose only
			return NEARNEARMEDIUM;							//return the firing rule
		}
		if (x == _NEAR && y == _NEAR && z == _FAR)			//3.	If sonar5 is NEAR, sonar6 is NEAR and sonar7 is FAR
		{
			//printf("NEARNEARFAR\n");					//Print this on the screen for debuging purpose only
			return NEARNEARFAR;								//return the firing rule
		}
		if (x == _NEAR && y == _MEDIUM && z == _NEAR)		//4.	If sonar5 is NEAR, sonar6 is MEDIUM and sonar7 is NEAR
		{
			//printf("NEARMEDIUMNEAR\n");				//Print this on the screen for debuging purpose only
			return NEARMEDIUMNEAR;							//return the firing rule
		}
		if (x == _NEAR && y == _MEDIUM && z == _MEDIUM)		//5.	If sonar5 is NEAR, sonar6 is MEDIUM and sonar7 is MEDIUM
		{
			//printf("NEARMEDIUMMEDIUM\n");				//Print this on the screen for debuging purpose only
			return NEARMEDIUMMEDIUM;
		}
		if (x == _NEAR && y == _MEDIUM && z == _FAR)		//6.	If sonar5 is NEAR, sonar6 is MEDIUM and sonar7 is FAR
		{
			//printf("NEARMEDIUMFAR\n");				//Print this on the screen for diagnostics only. it does not have efferct on the robot
			return NEARMEDIUMFAR;							//return NEARMEDIUMFAR as the firing rule
		}
		if (x == _NEAR && y == _FAR && z == _NEAR)			//7.	If sonar5 is NEAR, sonar6 is FAR and sonar7 is NEAR
		{
			//printf("NEARFARNEAR\n");					//Print this on the screen for diagnostics only
			return NEARMEDIUMNEAR;							//return NEARMEDIUMNEAR
		}
		if (x == _NEAR && y == _FAR && z == _MEDIUM)		//8.	If sonar5 is NEAR, sonar6 is FAR and sonar7 is MEDIUM
		{
			//printf("NEARFARMEDIUM\n");				//Print this on the screen for debuging purpose only
			return NEARFARMEDIUM;							//return NEARFARMEDIUM to the caller
		}
		if (x == _NEAR && y == _FAR && z == _FAR)			//9.	If sonar5 is NEAR, sonar6 is FAR and sonar7 is FAR
		{
			//printf("NEARFARFAR\n");					//Print this on the screen for debuging purpose only
			return NEARFARFAR;								// return NEARFARFAR as the firing rule
		}
		if (x == _MEDIUM && y == _NEAR && z == _NEAR)		//10.	If sonar5 is MEDIUM, sonar6 is NEAR and sonar7 is NEAR
		{
			//printf("MEDIUMNEARNEAR\n");				//Print this on the screen for debuging purpose only
			return MEDIUMNEARNEAR;							// return MEDIUMNEARNEAR to the caller
		}
		if (x == _MEDIUM && y == _NEAR && z == _MEDIUM)		//11.	If sonar5 is MEDIUM, sonar6 is NEAR and sonar7 is MEDIUM
		{
			//printf("MEDIUMNEARMEDIUM\n");				//Print this on the screen for debuging purpose only
			return MEDIUMNEARMEDIUM;						//return MEDIUMNEARMEDIUM to the caller function
		}
		if (x == _MEDIUM && y == _NEAR && z == _FAR)		//12.	If sonar5 is MEDIUM, sonar6 is NEAR and sonar7 is FAR
		{
			//printf("MEDIUMNEARFAR\n");				//Print this on the screen for debuging purpose
			return MEDIUMNEARFAR;							//return "MEDIUMNEARFAR to the caller function
		}
		if (x == _MEDIUM && y == _MEDIUM && z == _NEAR)		//13.	If sonar5 is MEDIUM, sonar6 is MEDIUM and sonar7 is NEAR
		{
			//printf("MEDIUMMEDIUMNEAR\n");				//Print this on the screen for debuging purpose
			return MEDIUMMEDIUMNEAR;						//return "MEDIUMMEDIUMNEAR to the caller function
		}
		if (x == _MEDIUM && y == _MEDIUM && z == _MEDIUM)	//14.	If sonar5 is MEDIUM, sonar6 is MEDIUM and sonar7 is MEDIUM
		{
			//printf("MEDIUMMEDIUMMEDIUM\n");			//Print this on the screen for debuging purpose
			return MEDIUMMEDIUMMEDIUM;
		}
		if (x == _MEDIUM && y == _MEDIUM && z == _FAR)		//15.	If sonar5 is MEDIUM, sonar6 is MEDIUM and sonar7 is FAR
		{
			//printf("MEDIUMMEDIUMFAR\n");				//Print this on the screen for debuging purpose
			return MEDIUMMEDIUMFAR;							//
		}
		if (x == _MEDIUM && y == _FAR && z == _NEAR)		//16.	If sonar5 is MEDIUM, sonar6 is FAR and sonar7 is NEAR
		{
			//printf("MEDIUMFARNEAR\n");				//Print this on the screen for debuging purpose
			return MEDIUMFARNEAR;
		}
		if (x == _MEDIUM && y == _FAR && z == _MEDIUM)		//17.	If sonar5 is MEDIUM, sonar6 is FAR and sonar7 is MEDIUM
		{
			//printf("MEDIUMFARMEDIUM\n");				//Print this on the screen for debuging purpose
			return MEDIUMFARMEDIUM;
		}
		if (x == _MEDIUM && y == _FAR && z == _FAR)			//18.	If sonar5 is MEDIUM, sonar6 is FAR and sonar7 is FAR
		{
			//printf("MEDIUMFARFAR\n");					//Print this on the screen for debuging purpose
			return MEDIUMFARFAR;
		}
		if (x == _FAR && y == _NEAR && z == _NEAR)			//19.	If sonar5 is FAR, sonar6 is NEAR and sonar7 is NEAR
		{
			//printf("FARNEARNEAR\n");					//Print this on the screen for debuging purpose
			return FARNEARNEAR;
		}
		if (x == _FAR && y == _NEAR && z == _MEDIUM)		//20.	If sonar5 is FAR, sonar6 is NEAR and sonar7 is MEDIUM
		{
			//printf("FARNEARNEAR\n");					//Print this on the screen for debuging purpose
			return FARNEARMEDIUM;
		}
		if (x == _FAR && y == _NEAR && z == _FAR)			//21.	If sonar5 is FAR, sonar6 is NEAR and sonar7 is FAR
		{
			//printf("FARNEARFAR\n");					//Print this on the screen for debuging purpose
			return FARNEARFAR;
		}
		if (x == _FAR && y == _MEDIUM && z == _NEAR)		//22.	If sonar5 is FAR, sonar6 is MEDIUM and sonar7 is NEAR
		{
			//printf("FARMEDIUMNEAR\n");				//Print this on the screen for debuging purpose
			return FARMEDIUMNEAR;
		}
		if (x == _FAR && y == _MEDIUM && z == _MEDIUM)		//23.	If sonar5 is FAR, sonar6 is MEDIUM and sonar7 is MEDIUM
		{
			//printf("FARMEDIUMMEDIUM\n");				//Print this on the screen for debuging purpose
			return FARMEDIUMMEDIUM;
		}
		if (x == _FAR && y == _MEDIUM && z == _FAR)			//24.	If sonar5 is FAR, sonar6 is MEDIUM and sonar7 is FAR
		{
			//printf("FARMEDIUMFAR\n");					//Print this on the screen for debuging purpose
			return FARMEDIUMFAR;
		}
		if (x == _FAR && y == _FAR && z == _NEAR)			//25.	If sonar5 is FAR, sonar6 is FAR and sonar7 is NEAR
		{
			//printf("FARFARNEAR\n");					//Print this on the screen for debuging purpose
			return FARFARNEAR;								//return FARFARNEAR as the firing rule
		}
		if (x == _FAR && y == _FAR && z == _MEDIUM)			//26.	If sonar5 is FAR, sonar6 is FAR and sonar7 is MEDIUM
		{
			//printf("FARFARMEDIUM\n");					//Print this on the screen for debuging purpose
			return FARFARMEDIUM;							//return FARFARMEDIUM as the firing rule
		}
		if (x == _FAR && y == _FAR && z == _FAR)			//27.	If sonar5 is FAR, sonar6 is FAR and sonar7 is FAR
		{
			//printf("FARFARFAR\n");					//Print this on the screen for debuging purpose
			return FARFARFAR;								//return FARFARFAR as the firing rule
		}
		return 0;  //just a guiding value. It will never get here
	}

	float getRightMotorSpeed(void)  //This is the access method that pass the left motor speed to the caller
	{
		return rmsValue;			//return the right motor speed
	}
	float getLeftMotorSpeed(void)	//This is the access method that pass the left motor speed to the caller
	{
		return lmsValue;			//return the left motor speed
	}

////////////////////////////////////////////////////////////////////////////Fuzzy Controller ends here////////////////////////////////

	void RobotMotorDrive(int PWMRight,int PWMLeft)
	{
//	    //motorA
//	    IN1_SetHigh() ;
//	    IN2_SetLow() ;
//	    //MotorB
//	    IN3_SetHigh() ;
//	    IN4_SetLow() ;
//	    EPWM1_LoadDutyValue(PWMRight);  //Ten bits PWM thus the duty cycle runs from 0-1023
//	    EPWM2_LoadDutyValue(PWMLeft); //Ten bits PWM thus the duty cycle runs from 0-1023

		//Run the motors to read the speeds
		/* Now drive motor A (Right) in the opposite direction*/
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //M2_IN3
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	//	M2dir = 0;
		htim15.Instance->CCR2 = (int)PWMRight;

		/* Now drive motor B (Left) in the opposite direction*/
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET); //M1_IN2
//		M1dir = 0;
		htim15.Instance->CCR1 = (int)PWMLeft;


	}








int encoder1PulseCntr,encoder2PulseCntr; //pulse counter for encoder
int M1rpm,M2rpm; //rmp measurement
uint8_t M1dir,M2dir; //store the direction of the motor
char uartBuffer[50];

void runTwoMotorTest(void)
{
	/*The two motor are connected with PWM for one motor provided
	 * on Pin PA2 (TIM15_CH1) and the motor switching pins for this
	 * motor are PA15 (M1_IN1) and PB3 (M1_IN2).
	 *
	 * The PWM for the second motor is provided on Pin PA3 (TIM15_CH2)
	 * and the motor switching pins for this motor are PB4 (M2_IN3) and
	 * PB5 (M2_IN4)
	 */

	/*First I will drive the motor in one direction with a constant PWM
	  signal set two 70%
	  */
	/* Now drive motor A in one direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	M1dir = 1;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in one direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	M2dir = 1;
	htim15.Instance->CCR2 = 50;
	HAL_Delay(2000);

	/* Now STOP motor A*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	htim15.Instance->CCR1 = 0;

	/*Now STOP motor B*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	htim15.Instance->CCR2 = 0;
	HAL_Delay(2000);

	/* Now drive motor A in the opposite direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET); //M1_IN2
	M1dir = 0;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in the opposite direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET); //M2_IN4
	M2dir = 0;
	htim15.Instance->CCR2 = 50;
	HAL_Delay(2000);

	/* Now STOP motor A*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	htim15.Instance->CCR1 = 0;

	/*Now STOP motor B*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	htim15.Instance->CCR2 = 0;

	HAL_Delay(2000);
}

void runTwoMotorTestVariablePWMDuty(void)
{
	/*The two motor are connected with PWM for one motor provided
	 * on Pin PA2 (TIM15_CH1) and the motor switching pins for this
	 * motor are PA15 (M1_IN1) and PB3 (M1_IN2).
	 *
	 * The PWM for the second motor is provided on Pin PA3 (TIM15_CH2)
	 * and the motor switching pins for this motor are PB4 (M2_IN3) and
	 * PB5 (M2_IN4)
	 */

	/*This function will run the motors with a variable PWM duty cycle.
	 * First incrementing the duty cycle and then reducing the duty
	 * cycle will bring the motors to halt.
	 */
	/* Now drive motor A in one direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	M1dir = 1;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in one direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	M2dir = 1;
	htim15.Instance->CCR2 = 50;
	//HAL_Delay(2000);

	for(int i = 0;i<100;i++)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
		HAL_Delay(100);
	}
	HAL_Delay(1000);

	for(int i = 100;i>0;i--)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
	}
	HAL_Delay(2000);

	/* Now drive motor A in the opposite direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET); //M1_IN2
	M1dir = 0;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in the opposite direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET); //M2_IN4
	M2dir = 0;
	htim15.Instance->CCR2 = 50;

	for(int i = 0;i<100;i++)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
		HAL_Delay(100);
	}
	HAL_Delay(1000);

	for(int i = 100;i>0;i--)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
	}
	HAL_Delay(2000);
}




//These are variables used by the capture compare module
/*
 * This delay function can only be used to created delays for reading the Ultrasonic module,
 * if its used for something else, it may interfere with the reading of the ultrasonic module
 */

uint32_t IC_Val1 = 0;
uint32_t IC_Val2 = 0;
uint32_t Difference = 0;
uint8_t Is_First_Captured = 0; // is the first value captured ?
uint8_t Distance = 0;
double distance[4]={0.00,0.00,0.00};
uint8_t sonar = 0;
char USARTOneBuffer[100] = {0};


void delay_us(uint32_t us)
{
	__HAL_TIM_SET_COUNTER(&htim1,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim1) < us);  // wait for the counter to reach the us input in the parameter
}


//// Let's write the callback function
//
//void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
//{
//	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)  // if the interrupt source is channel1
//	{
//		if (Is_First_Captured==0) // if the first value is not captured
//		{
//			IC_Val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read the first value
//			Is_First_Captured = 1;  // set the first captured as true
//			// Now change the polarity to falling edge
//			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
//		}
//
//		else if (Is_First_Captured==1)   // if the first is already captured
//		{
//			IC_Val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);  // read second value
//			__HAL_TIM_SET_COUNTER(htim, 0);  // reset the counter
//
//			if (IC_Val2 > IC_Val1)
//			{
//				Difference = IC_Val2-IC_Val1;
//			}
//
//			else if (IC_Val1 > IC_Val2)
//			{
//				Difference = (0xffff - IC_Val1) + IC_Val2;
//			}
//
//			//Distance = Difference * .034/2;
//			distance[0] = Difference * .034/2;
//			Is_First_Captured = 0; // set it back to false
//
//			// set polarity to rising edge
//			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
//			__HAL_TIM_DISABLE_IT(&htim1, TIM_IT_CC1);
//		}
//	}
//}
//
//void HCSR04_Read (void)
//{
//	HAL_GPIO_WritePin(TRIG2_GPIO_Port,TRIG2_Pin,SET);		// pull the TRIG pin HIGH
//	delay_us(8);  // wait for 10 us
//	HAL_GPIO_WritePin(TRIG2_GPIO_Port,TRIG2_Pin,RESET);		// pull the TRIG pin low
//	__HAL_TIM_ENABLE_IT(&htim1, TIM_IT_CC1);
//}


// Let's write the callback function
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1) // if the interrupt source is channel1
	{
		if (Is_First_Captured==0) // if the first value is not captured
		{
			IC_Val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read the first value
			Is_First_Captured = 1; // set the first captured as true
			// Now change the polarity to falling edge
			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1,TIM_INPUTCHANNELPOLARITY_FALLING);
		}
		else if (Is_First_Captured==1) // if the first is already captured
		{
			IC_Val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read second value
			__HAL_TIM_SET_COUNTER(htim, 0); // reset the counter
			if (IC_Val2 > IC_Val1)
			{
				Difference = IC_Val2-IC_Val1;
			}
			else if (IC_Val1 > IC_Val2)
			{
				Difference = (0xffff - IC_Val1) + IC_Val2;
			}
			//Distance = Difference * .034/2;
			if(sonar == 0)
			{
			distance[0] = Difference * .034/2;
			}
			else if(sonar ==1)
			{
			distance[1] = Difference * .034/2;
			}
			else if(sonar ==2)
			{
			distance[2] = Difference * .034/2;
			}
//			else if(sonar ==3)
//			{
//			distance[3] = Difference * .034/2;
//			}
			// if(sonar++ >3) //if sonar is greater than or equals to 3, reset it to 0
			// sonar = 0;
			Is_First_Captured = 0; // set it back to false
			// set polarity to rising edge
			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1,TIM_INPUTCHANNELPOLARITY_RISING);
			__HAL_TIM_DISABLE_IT(&htim1, TIM_IT_CC1);
		}
	}
}
// Let's write the callback function






void HCSR04_Read (uint8_t sonar)
{
	switch(sonar)
	{
		case 0:
			HAL_GPIO_WritePin(TRIG2_GPIO_Port,TRIG2_Pin,SET); // pull the TRIG pin HIGH
			delay_us(10); // wait for 10 us
			HAL_GPIO_WritePin(TRIG2_GPIO_Port,TRIG2_Pin,RESET); // pull the TRIG pin low
			__HAL_TIM_ENABLE_IT(&htim1, TIM_IT_CC1);
		break;
		case 1:
			HAL_GPIO_WritePin(TRIG3_GPIO_Port,TRIG3_Pin,SET); // pull the TRIG pin HIGH
			delay_us(10); // wait for 10 us
			HAL_GPIO_WritePin(TRIG3_GPIO_Port,TRIG3_Pin,RESET); // pull the TRIG pin low
			__HAL_TIM_ENABLE_IT(&htim1, TIM_IT_CC1);
		break;
		case 2:
			HAL_GPIO_WritePin(TRIG5_GPIO_Port,TRIG5_Pin,SET); // pull the TRIG pin HIGH
			delay_us(10); // wait for 10 us
			HAL_GPIO_WritePin(TRIG5_GPIO_Port,TRIG5_Pin,RESET); // pull the TRIG pin low
			__HAL_TIM_ENABLE_IT(&htim1, TIM_IT_CC1);
		break;
		default:  //error
			sonar=0;
			break;
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_TIM15_Init();
  MX_TIM1_Init();
  MX_TIM14_Init();
  /* USER CODE BEGIN 2 */
  /*
   * I have set the prescaler to 48 and the ARR to 100 to create a 10KHz
   * PWM signal.
   */
  HAL_TIM_PWM_Start(&htim15, TIM_CHANNEL_1); //start PWM with timer15 on channel one
  HAL_TIM_PWM_Start(&htim15, TIM_CHANNEL_2); //start PWM with timer15 on channel two

  //Timer 3 will be used to flash the led on PA0
  //HAL_TIM_Base_Start_IT(&htim3);  //Start timer3 in the interrupt mode
  //Start Timer one for input capture compare interrupts
  //HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_1);
 // HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_1);

  //Run the motors to read the speeds
  /* Now drive motor B (Left) in the opposite direction*/
  	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
  	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET); //M1_IN2
  	M1dir = 0;
  	htim15.Instance->CCR1 = 60;

  	/* Now drive motor A (Right) in the opposite direction*/
  	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //M2_IN3
  	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
  	M2dir = 0;
  	htim15.Instance->CCR2 = 60;

  	//Timer 3 will be used to flash the led on PA0
  	//HAL_TIM_Base_Start_IT(&htim3);  //Start timer3 in the interrupt mode
  	HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_1);
  	sonar = 0;
  	HAL_TIM_Base_Start_IT(&htim14);  //Start timer14 in the interrupt mode. This timer is used to read the sonar sensors
  	HAL_UART_Transmit(&huart1,(uint8_t*) "Hello World!!\r\n", strlen("Hello World!!\r\n"), 100);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (TRUE)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  //	  HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
	  //	  delay_us(8);  //in this microcontroller code, if one call for 8us delay, this is actually equal to about 10us in real life.
	  //	  	  	  	  	  //This is the result of the timer error in this microcontroller.

//	  /*
//	   * The part below with one sensor worked well.
//	   * I comment it out and start testing for multiple sonar sensor
//	   */
//	  	  HCSR04_Read ();
//	  	  sprintf(USARTOneBuffer,"Dist= %.2f cm\r\n",distance[0]);
//	  	  HAL_UART_Transmit(&huart1,(uint8_t*) USARTOneBuffer, strlen(USARTOneBuffer), 100);
//	  	  HAL_Delay(500);

//	  //HCSR04_Read ();
//	  sprintf(USARTOneBuffer,"Dist= %.2f cm \t%.2f cm \t%.2f cm\r\n",distance[0],distance[1],distance[2]);
//	  HAL_UART_Transmit(&huart1,(uint8_t*) USARTOneBuffer, strlen(USARTOneBuffer), 100);
//	  HAL_Delay(500);
//	  sonar++;
//	  if(sonar >=3) //if sonar is greater than or equals to 3, reset it to 0
//		  sonar = 0;

	  GetDegreeOfMembershipValue(distance[0], distance[1], distance[2] );
	  RobotMotorDrive(rmsValue,lmsValue);
//	  sprintf(USARTOneBuffer,"Dist= %.2f cm \t%.2f cm \t%.2f cm \tRMotor: %.2f \t LMotor: %.2f \r\n",distance[0],distance[1],distance[2],rmsValue,lmsValue);
//	  HAL_UART_Transmit(&huart1,(uint8_t*) USARTOneBuffer, strlen(USARTOneBuffer), 100);
//	  HAL_Delay(500);






//	  HAL_UART_Transmit(&huart1,(uint8_t*)"Reading sensor\r\n",strlen("Reading sensor\r\n"),100);
//	  HYSRF05LeftSensor();
//	  HAL_UART_Transmit(&huart1,(uint8_t*)"Sensor reading done\r\n",strlen("Sensor reading done\r\n"),100);
//	  sprintf(USARTOneBuffer,"Dist = %.2f cm\r\n",distance);
//	  HAL_UART_Transmit(&huart1,(uint8_t*)USARTOneBuffer,strlen(USARTOneBuffer),100);
//	  HAL_Delay(500);






	  // HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
//	  	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
//	  	  HAL_Delay(200);
//	  	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
//	  	  HAL_Delay(200);

	  	  //HAL_UART_Transmit(&huart1, (uint8_t *)"Hello world\r\n", sizeof("Hello world\r\n"), 10);
	  	  //runTwoMotorTest();
	  	  //runTwoMotorTestVariablePWMDuty();
//	  	  sprintf(uartBuffer, "Encoder1: %d \t Encoder2: %d \r\n",encoder1PulseCntr,encoder2PulseCntr);
//	  	  HAL_UART_Transmit(&huart1, (uint8_t *)uartBuffer, sizeof(uartBuffer), 10);
//	  	  HAL_Delay(500);
	  	  //HAL_Delay(500);
	  	  //encoder1PulseCntr = 0;
	  	  //encoder2PulseCntr = 0;

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 48-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 0xffff-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM14 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM14_Init(void)
{

  /* USER CODE BEGIN TIM14_Init 0 */

  /* USER CODE END TIM14_Init 0 */

  /* USER CODE BEGIN TIM14_Init 1 */

  /* USER CODE END TIM14_Init 1 */
  htim14.Instance = TIM14;
  htim14.Init.Prescaler = 48-1;
  htim14.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim14.Init.Period = 10000-1;
  htim14.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim14.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim14) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM14_Init 2 */

  /* USER CODE END TIM14_Init 2 */

}

/**
  * @brief TIM15 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM15_Init(void)
{

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 20-1;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 100-1;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim15, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim15, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim15, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM15_Init 2 */

  /* USER CODE END TIM15_Init 2 */
  HAL_TIM_MspPostInit(&htim15);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|TRIG5_Pin|TRIG3_Pin|TRIG2_Pin
                          |M1_IN1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, M1_IN2_Pin|M2_IN3_Pin|M2_IN4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA0 TRIG5_Pin TRIG3_Pin TRIG2_Pin
                           M1_IN1_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_0|TRIG5_Pin|TRIG3_Pin|TRIG2_Pin
                          |M1_IN1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : M2DATA_Pin M1DATA_Pin */
  GPIO_InitStruct.Pin = M2DATA_Pin|M1DATA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : M1_IN2_Pin M2_IN3_Pin M2_IN4_Pin */
  GPIO_InitStruct.Pin = M1_IN2_Pin|M2_IN3_Pin|M2_IN4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
//void HAL_TIM_PerioElapsedCallBack(TIM_HandleTypeDef* htim)
//{
//	if(htim->Instance ==TIM3 )
//	{
//		//HAL_GPIO_TogglePin(GPIOA, GPIO_Pin)
//		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
//	}
//}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
